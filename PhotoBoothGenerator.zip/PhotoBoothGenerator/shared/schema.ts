import { pgTable, text, serial, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const photoStrips = pgTable("photo_strips", {
  id: serial("id").primaryKey(),
  photos: jsonb("photos").array().notNull(),
  frameColor: text("frame_color").notNull(),
  showDate: text("show_date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertPhotoStripSchema = createInsertSchema(photoStrips).pick({
  photos: true,
  frameColor: true,
  showDate: true
});

export type InsertPhotoStrip = z.infer<typeof insertPhotoStripSchema>;
export type PhotoStrip = typeof photoStrips.$inferSelect;
