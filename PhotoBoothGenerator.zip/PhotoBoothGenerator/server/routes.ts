import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertPhotoStripSchema } from "@shared/schema";
import express from "express";
import compression from "express-compression";

export async function registerRoutes(app: Express) {
  app.use(compression());
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));
  app.post("/api/photo-strips", async (req, res) => {
    try {
      const photoStrip = insertPhotoStripSchema.parse(req.body);
      const created = await storage.createPhotoStrip(photoStrip);
      res.json(created);
    } catch (err) {
      res.status(400).json({ error: "Invalid photo strip data" });
    }
  });

  app.get("/api/photo-strips/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const photoStrip = await storage.getPhotoStrip(id);
    if (!photoStrip) {
      res.status(404).json({ error: "Photo strip not found" });
      return;
    }
    res.json(photoStrip);
  });

  return createServer(app);
}
