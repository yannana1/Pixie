import { useEffect, useRef } from "react";
import { format } from "date-fns";

interface PhotoStripProps {
  photos: string[];
  frameColor: string;
  showDate: boolean;
}

export function PhotoStrip({ photos, frameColor, showDate }: PhotoStripProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas dimensions for a more compact photo strip
    canvas.width = 900;
    canvas.height = 1800;

    // Clear canvas first
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw background
    ctx.fillStyle = frameColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Load and draw photos
    const loadAndDrawPhoto = (photoData: string, index: number) => {
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
        // Calculate photo position with more space at bottom
        const photoHeight = canvas.height / 3 - 100;
        const photoWidth = canvas.width - 100;
        const x = 50;
        const y = index * (canvas.height / 3.5) + 50;

        // Calculate dimensions to maintain aspect ratio
        const scale = Math.min(photoWidth / img.width, photoHeight / img.height);
        const scaledWidth = img.width * scale;
        const scaledHeight = img.height * scale;
        const offsetX = x + (photoWidth - scaledWidth) / 2;
        const offsetY = y + (photoHeight - scaledHeight) / 2;

        // Add border around each photo that fits the actual photo size
        ctx.strokeStyle = "white";
        ctx.lineWidth = 4;
        ctx.strokeRect(offsetX, offsetY, scaledWidth, scaledHeight);
        
        // Draw the photo maintaining aspect ratio
        ctx.drawImage(img, offsetX, offsetY, scaledWidth, scaledHeight);

        // Add date if enabled
        if (showDate) {
          // Calculate contrasting text color
          const brightness = parseInt(frameColor.slice(1), 16);
          const textColor = brightness > 0x7FFFFF ? '#000000' : '#FFFFFF';
          
          // Add Pixiebooth title
          ctx.fillStyle = textColor;
          ctx.font = "bold 72px Arial";
          ctx.textAlign = "center";
          ctx.fillText("Pixiebooth", canvas.width / 2, canvas.height - 100);
          
          // Add date below title
          const date = format(new Date(), "MMM d, yyyy");
          ctx.font = "bold 48px Arial";
          ctx.fillText(date, canvas.width / 2, canvas.height - 40);
        }
        resolve();
      };
      img.src = photoData;
    });
  };

    // Draw placeholder rectangles for missing photos
    for (let i = 0; i < 3; i++) {
      const photoHeight = canvas.height / 3 - 100;
      const photoWidth = canvas.width - 100;
      const x = 50;
      const y = i * (canvas.height / 3) + 50;

      ctx.fillStyle = frameColor;
      ctx.fillRect(x, y, photoWidth, photoHeight);
    }

    // Draw actual photos on top of placeholders
    Promise.all(photos.map(loadAndDrawPhoto));
  }, [photos, frameColor, showDate]);

  return (
    <canvas
      id="photo-strip"
      ref={canvasRef}
      className="w-full max-w-[300px] mx-auto shadow-xl"
      style={{ aspectRatio: "1/3" }}
    />
  );
}
