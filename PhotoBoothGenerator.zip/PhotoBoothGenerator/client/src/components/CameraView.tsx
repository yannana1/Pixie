import { useRef, useCallback, useState } from "react";
import Webcam from "react-webcam";
import { Button } from "@/components/ui/button";
import { FlipHorizontal } from "lucide-react";

interface CameraViewProps {
  onCapture: (photoData: string) => void;
  filter?: string;
}

export function CameraView({ onCapture, filter = "none" }: CameraViewProps) {
  const webcamRef = useRef<Webcam>(null);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      onCapture(imageSrc);
    }
  }, [onCapture]);

  const toggleCamera = () => {
    setFacingMode(prev => prev === "user" ? "environment" : "user");
  };

  const filterStyles: Record<string, string> = {
    none: "",
    grayscale: "grayscale(100%)",
    sepia: "sepia(100%)",
    blur: "blur(2px)"
  };

  return (
    <div className="relative aspect-video max-w-4xl mx-auto rounded-lg overflow-hidden">
      <Webcam
        audio={false}
        ref={webcamRef}
        screenshotFormat="image/jpeg"
        videoConstraints={{
          width: 1280,
          height: 720,
          facingMode
        }}
        mirrored={true}
        className="w-full h-full object-cover"
        style={{ filter: filterStyles[filter] }}
      />
      <Button
        variant="secondary"
        size="icon"
        className="absolute bottom-4 right-4 bg-white/80 hover:bg-white"
        onClick={toggleCamera}
      >
        <FlipHorizontal className="h-4 w-4" />
      </Button>
    </div>
  );
}