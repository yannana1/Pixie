import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { PhotoStrip } from "@/components/PhotoStrip";
import { ColorPicker } from "@/components/ColorPicker";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { usePhotoStore } from "@/lib/photoStore";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Customize() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { photos } = usePhotoStore();
  const [frameColor, setFrameColor] = useState("#FF69B4");
  const [showDate, setShowDate] = useState(true);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      const optimizedPhotos = await Promise.all(photos.map(async (photo) => {
        const img = new Image();
        await new Promise((resolve) => {
          img.onload = resolve;
          img.src = photo;
        });
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 600; // Further reduced size
        canvas.height = 450;
        ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL('image/jpeg', 0.6); // Increased compression
      }));

      const response = await apiRequest("POST", "/api/photo-strips", {
        photos: optimizedPhotos,
        frameColor,
        showDate: showDate.toString()
      });
      const data = await response.json();
      navigate(`/download/${data.id}`);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to save photo strip",
        description: "Please try again"
      });
    }
    setSaving(false);
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold mb-6">Customize Your Strip</h2>
          <div className="space-y-6">
            <div>
              <Label>Frame Color</Label>
              <ColorPicker color={frameColor} onChange={setFrameColor} />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="show-date"
                checked={showDate}
                onCheckedChange={setShowDate}
              />
              <Label htmlFor="show-date">Show Date</Label>
            </div>
            <Button
              className="w-full"
              size="lg"
              onClick={handleSave}
              disabled={saving}
            >
              Continue to Download
            </Button>
          </div>
        </div>
        <div>
          <PhotoStrip
            photos={photos}
            frameColor={frameColor}
            showDate={showDate}
          />
        </div>
      </div>
    </div>
  );
}
